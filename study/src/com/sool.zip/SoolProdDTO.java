package com.sool;

public class SoolProdDTO {
	
	public int prod_no;
	public String prod_name;
	public int prod_price;
	public int prod_quan;
	public String prod_oImg;
	public String prod_sImg;
	public String prod_cate;
	
	public int getProd_no() {
		return prod_no;
	}
	public void setProd_no(int prod_no) {
		this.prod_no = prod_no;
	}
	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	public int getProd_price() {
		return prod_price;
	}
	public void setProd_price(int prod_price) {
		this.prod_price = prod_price;
	}
	public int getProd_quan() {
		return prod_quan;
	}
	public void setProd_quan(int prod_quan) {
		this.prod_quan = prod_quan;
	}
	public String getProd_oImg() {
		return prod_oImg;
	}
	public void setProd_oImg(String prod_oImg) {
		this.prod_oImg = prod_oImg;
	}
	public String getProd_sImg() {
		return prod_sImg;
	}
	public void setProd_sImg(String prod_sImg) {
		this.prod_sImg = prod_sImg;
	}
	public String getProd_cate() {
		return prod_cate;
	}
	public void setProd_cate(String prod_cate) {
		this.prod_cate = prod_cate;
	}
	
	

}
