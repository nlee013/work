package com.sool;

public class SoolUserDTO {
	 
	//ȸ����� user 
	private String user_id;
	private String user_pwd;
	private String user_nick;
	private String user_name;
	private String user_tel;
	private String user_email;
	private String user_addr1;
	private String user_addr2;
	private String user_gender;
	private int user_bir1;
	private int user_bir2;
	private int user_bir3;
	private String user_rid;
	private String user_date;
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_pwd() {
		return user_pwd;
	}
	public void setUser_pwd(String user_pwd) {
		this.user_pwd = user_pwd;
	}
	public String getUser_nick() {
		return user_nick;
	}
	public void setUser_nick(String user_nick) {
		this.user_nick = user_nick;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_tel() {
		return user_tel;
	}
	public void setUser_tel(String user_tel) {
		this.user_tel = user_tel;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getUser_addr1() {
		return user_addr1;
	}
	public void setUser_addr1(String user_addr1) {
		this.user_addr1 = user_addr1;
	}
	public String getUser_addr2() {
		return user_addr2;
	}
	public void setUser_addr2(String user_addr2) {
		this.user_addr2 = user_addr2;
	}
	public String getUser_gender() {
		return user_gender;
	}
	public void setUser_gender(String user_gender) {
		this.user_gender = user_gender;
	}
	public int getUser_bir1() {
		return user_bir1;
	}
	public void setUser_bir1(int user_bir1) {
		this.user_bir1 = user_bir1;
	}
	public int getUser_bir2() {
		return user_bir2;
	}
	public void setUser_bir2(int user_bir2) {
		this.user_bir2 = user_bir2;
	}
	public int getUser_bir3() {
		return user_bir3;
	}
	public void setUser_bir3(int user_bir3) {
		this.user_bir3 = user_bir3;
	}
	public String getUser_rid() {
		return user_rid;
	}
	public void setUser_rid(String user_rid) {
		this.user_rid = user_rid;
	}
	public String getUser_date() {
		return user_date;
	}
	public void setUser_date(String user_date) {
		this.user_date = user_date;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
